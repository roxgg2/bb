<?php

namespace Drupal\doctor_appointment\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Form for managing doctor's availability.
 */
class ManageAvailabilityForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'manage_availability_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $user = \Drupal::currentUser();
    $doctor_nodes = \Drupal::entityTypeManager()->getStorage('doctor')->loadByProperties([
      'uid' => $user->id(),
    ]);

    if (!$doctor_nodes) {
      $form['error'] = [
        '#markup' => $this->t('You are not associated with a doctor profile.'),
      ];
      return $form;
    }

    $doctor = reset($doctor_nodes);
    $form_state->set('doctor', $doctor);

    $availability = $doctor->get('availability')->getValue();
    $times = array_column($availability, 'value');

    $form['availability'] = [
      '#type' => 'checkboxes',
      '#title' => $this->t('Available Time Slots'),
      '#options' => [
        '9AM' => '9AM',
        '10AM' => '10AM',
        '11AM' => '11AM',
        '12PM' => '12PM',
        '1PM' => '1PM',
        '2PM' => '2PM',
        '3PM' => '3PM',
        '4PM' => '4PM',
        '5PM' => '5PM',
      ],
      '#default_value' => $times,
    ];

    $form['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Save Availability'),
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $doctor = $form_state->get('doctor');
    $times = array_filter($form_state->getValue('availability'));
    $doctor->set('availability', array_values($times));
    $doctor->save();

    \Drupal::messenger()->addMessage($this->t('Availability updated.'));
    $form_state->setRedirect('doctor_appointment.dashboard');
  }

}
