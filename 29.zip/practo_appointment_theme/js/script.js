document.addEventListener('DOMContentLoaded', function () {
  const toggle = document.querySelector('.nav-toggle');
  const menu = document.querySelector('.nav-menu');
  if (toggle && menu) {
    toggle.addEventListener('click', () => {
      menu.classList.toggle('active');
    });
  }

  // Search functionality for doctors by specialty - redirect to search results page
  window.searchDoctors = function() {
    const searchInput = document.getElementById('specialty-search');
    const searchTerm = searchInput.value.toLowerCase().trim();

    if (searchTerm) {
      // Redirect to search results page with specialty parameter
      window.location.href = '/search-doctors?specialty=' + encodeURIComponent(searchTerm);
    } else {
      // If no search term, redirect to general doctors list
      window.location.href = '/doctors';
    }
  };

  // Allow search on Enter key press
  const searchInput = document.getElementById('specialty-search');
  if (searchInput) {
    searchInput.addEventListener('keypress', function(e) {
      if (e.key === 'Enter') {
        searchDoctors();
      }
    });
  }
});
