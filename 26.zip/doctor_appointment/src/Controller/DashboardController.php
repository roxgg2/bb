<?php

namespace Drupal\doctor_appointment\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * Controller for the dashboard page.
 */
class DashboardController extends ControllerBase {

  /**
   * Displays the dashboard content based on user role.
   */
  public function content() {
    $user = $this->currentUser();
    return [
      '#theme' => 'dashboard',
      '#user' => $user,
    ];
  }

}
