# TODO: Make Pages Standalone and Add Logout

## Tasks
- [x] Remove header and footer from login.html
- [x] Remove header and footer from signup.html
- [x] Remove header and footer from dashboard.html and add logout button
- [x] Remove header and footer from book-appointment.html and add logout button
- [x] Remove header and footer from view-appointments.html and add logout button
- [x] Remove header and footer from manage-appointments.html and add logout button
- [x] Remove header and footer from manage-availability.html and add logout button
- [x] Remove header and footer from select-time.html and add logout button
- [x] Remove header and footer from confirm-appointment.html and add logout button
- [x] Update app.js to handle pages without header-actions
- [x] Test all pages for standalone functionality
