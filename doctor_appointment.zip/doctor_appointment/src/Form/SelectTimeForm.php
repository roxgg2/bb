<?php

namespace Drupal\doctor_appointment\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\doctor_appointment\Entity\Doctor;

/**
 * Form for selecting date and time for appointment.
 */
class SelectTimeForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'select_time_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, Doctor $doctor = NULL) {
    $form_state->set('doctor', $doctor);

    $availability = $doctor->get('availability')->getValue();
    $times = array_column($availability, 'value');

    $form['date'] = [
      '#type' => 'date',
      '#title' => $this->t('Select Date'),
      '#required' => TRUE,
    ];

    $form['time'] = [
      '#type' => 'checkboxes',
      '#title' => $this->t('Available Time Slots'),
      '#options' => array_combine($times, $times),
      '#required' => TRUE,
    ];

    $form['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Next: Confirm Appointment'),
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $doctor = $form_state->get('doctor');
    $date = $form_state->getValue('date');
    $times = array_filter($form_state->getValue('time'));

    $tempstore = \Drupal::service('tempstore.private')->get('doctor_appointment');
    $tempstore->set('doctor_id', $doctor->id());
    $tempstore->set('date', $date);
    $tempstore->set('times', $times);

    $form_state->setRedirect('doctor_appointment.confirm');
  }

}
