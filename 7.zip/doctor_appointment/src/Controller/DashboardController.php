<?php

namespace Drupal\doctor_appointment\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * Controller for the dashboard page.
 */
class DashboardController extends ControllerBase {

  /**
   * Displays the dashboard content based on user role.
   */
  public function content() {
    $user = $this->currentUser();
    $build = [
      '#theme' => 'dashboard',
      '#user' => $user,
    ];

    // Add logout link
    $build['#attached']['library'][] = 'core/drupal.ajax';
    $build['#attached']['drupalSettings']['logout_url'] = $this->url('user.logout', [], ['query' => ['destination' => '<front>']]);

    return $build;
  }

}
