document.addEventListener('DOMContentLoaded', function () {
  const toggle = document.querySelector('.nav-toggle');
  const menu = document.querySelector('.nav-menu');
  if (toggle && menu) {
    toggle.addEventListener('click', () => {
      menu.classList.toggle('active');
    });
  }

  // Search functionality for doctors by specialty
  window.filterDoctors = function() {
    const searchInput = document.getElementById('specialty-search');
    const searchTerm = searchInput.value.toLowerCase().trim();
    const doctorCards = document.querySelectorAll('.doctor-card');

    if (!searchTerm) {
      // Show all doctors if search is empty
      doctorCards.forEach(card => {
        card.style.display = 'block';
      });
      return;
    }

    doctorCards.forEach(card => {
      const specialization = card.querySelector('.doctor-specialization');
      if (specialization) {
        const specText = specialization.textContent.toLowerCase();
        if (specText.includes(searchTerm)) {
          card.style.display = 'block';
        } else {
          card.style.display = 'none';
        }
      } else {
        card.style.display = 'none';
      }
    });
  };

  // Allow search on Enter key press
  const searchInput = document.getElementById('specialty-search');
  if (searchInput) {
    searchInput.addEventListener('keypress', function(e) {
      if (e.key === 'Enter') {
        filterDoctors();
      }
    });
  }
});
