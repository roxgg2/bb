from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Any

app = FastAPI()

# Allow requests from any origin (covers localhost:3000, localhost:3001, etc.)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Request model ──────────────────────────────────────────────
class Pipeline(BaseModel):
    nodes: List[Any]
    edges: List[Any]

# ── DAG detection via DFS cycle check ──────────────────────────
def check_is_dag(nodes: list, edges: list) -> bool:
    """Return True when the graph is a Directed Acyclic Graph."""
    node_ids = {n["id"] for n in nodes}
    # Build adjacency list (only include edges whose endpoints exist)
    graph: dict[str, list] = {n["id"]: [] for n in nodes}
    for e in edges:
        src, tgt = e.get("source"), e.get("target")
        if src in graph and tgt in node_ids:
            graph[src].append(tgt)

    # 3-colour DFS: WHITE = unvisited, GRAY = in stack, BLACK = done
    WHITE, GRAY, BLACK = 0, 1, 2
    colour = {nid: WHITE for nid in graph}

    def dfs(node: str) -> bool:
        """Returns True if a back-edge (cycle) is found."""
        colour[node] = GRAY
        for neighbour in graph.get(node, []):
            if colour.get(neighbour) == GRAY:
                return True          # back-edge → cycle
            if colour.get(neighbour) == WHITE:
                if dfs(neighbour):
                    return True
        colour[node] = BLACK
        return False

    for nid in list(graph):
        if colour[nid] == WHITE:
            if dfs(nid):
                return False          # cycle found → not a DAG

    return True

# ── Endpoints ──────────────────────────────────────────────────
@app.get("/")
def read_root():
    return {"Ping": "Pong"}

@app.post("/pipelines/parse")
def parse_pipeline(pipeline: Pipeline):
    num_nodes = len(pipeline.nodes)
    num_edges = len(pipeline.edges)
    is_dag    = check_is_dag(pipeline.nodes, pipeline.edges)
    return {
        "num_nodes": num_nodes,
        "num_edges": num_edges,
        "is_dag":    is_dag,
    }
