// Mock Data
let users = JSON.parse(localStorage.getItem('users')) || [];

// Ensure default users are present
const defaultUsers = [
  { id: 1, name: 'John Patient', email: 'patient@example.com', password: 'pass123', role: 'patient' },
  { id: 1, name: 'Dr. Alice Johnson', email: 'alice@example.com', password: 'pass123', role: 'doctor' },
  { id: 2, name: 'Dr. Bob Lee', email: 'bob@example.com', password: 'pass123', role: 'doctor' },
  { id: 3, name: 'Dr. Carol Davis', email: 'carol@example.com', password: 'pass123', role: 'doctor' },
  { id: 4, name: 'Dr. David Wilson', email: 'david@example.com', password: 'pass123', role: 'doctor' },
  { id: 5, name: 'Dr. Eve Brown', email: 'eve@example.com', password: 'pass123', role: 'doctor' }
];

defaultUsers.forEach(defaultUser => {
  if (!users.find(u => u.email === defaultUser.email)) {
    users.push(defaultUser);
  }
});
let doctors = JSON.parse(localStorage.getItem('doctors')) || [
  { id: 1, name: 'Dr. Alice Johnson', specialty: 'Cardiology', location: 'New York', availability: ['9AM', '10AM', '2PM', '3PM'] },
  { id: 2, name: 'Dr. Bob Lee', specialty: 'Dermatology', location: 'Los Angeles', availability: ['11AM', '12PM', '4PM'] },
  { id: 3, name: 'Dr. Carol Davis', specialty: 'Pediatrics', location: 'Chicago', availability: ['9AM', '1PM', '5PM'] },
  { id: 4, name: 'Dr. David Wilson', specialty: 'Orthopedics', location: 'Houston', availability: ['10AM', '11AM', '3PM'] },
  { id: 5, name: 'Dr. Eve Brown', specialty: 'Neurology', location: 'Phoenix', availability: ['12PM', '2PM', '4PM'] }
];

let appointments = JSON.parse(localStorage.getItem('appointments')) || [];

// Save to localStorage
function saveData() {
  localStorage.setItem('users', JSON.stringify(users));
  localStorage.setItem('doctors', JSON.stringify(doctors));
  localStorage.setItem('appointments', JSON.stringify(appointments));
}

// Auth Functions
function checkAuth() {
  const user = JSON.parse(localStorage.getItem('currentUser'));
  const token = localStorage.getItem('token');
  if (user && token && Date.now() - parseInt(token) < 24 * 60 * 60 * 1000) { // 24h session
    return user;
  }
  localStorage.removeItem('currentUser');
  localStorage.removeItem('token');
  return null;
}

function login(email, password) {
  const user = users.find(u => u.email === email && u.password === password);
  if (user) {
    localStorage.setItem('currentUser', JSON.stringify(user));
    localStorage.setItem('token', Date.now().toString());
    updateHeader(user);
    window.location.href = 'dashboard.html';
    return true;
  }
  alert('Invalid email or password');
  return false;
}

function signup(name, email, password, role) {
  if (users.find(u => u.email === email)) {
    alert('Email already exists');
    return false;
  }
  const newUser = { id: users.length + 1, name, email, password, role };
  users.push(newUser);
  saveData();
  login(email, password); // Auto-login
  return true;
}

function logout() {
  localStorage.removeItem('currentUser');
  localStorage.removeItem('token');
  updateHeader(null);
  window.location.href = 'index.html';
}

// Header Update
function updateHeader(user) {
  const actions = document.getElementById('header-actions');
  if (actions) {
    if (user) {
      actions.innerHTML = `
        <span>Welcome, ${user.name} (${user.role})</span>
        <button onclick="logout()" style="background: none; border: none; color: white; cursor: pointer; text-decoration: underline;">Logout</button>
      `;
    } else {
      actions.innerHTML = `
        <a href="login.html" style="color: white; text-decoration: none; margin-right: 10px;">Login</a>
        <a href="signup.html" style="color: white; text-decoration: none;">Signup</a>
      `;
    }
  }
}

// Protect Pages
function protectPage() {
  if (!checkAuth()) {
    window.location.href = 'login.html';
  }
}

// Init on Load
document.addEventListener('DOMContentLoaded', function() {
  const user = checkAuth();
  updateHeader(user);
  if (window.location.pathname.includes('dashboard') || window.location.pathname.includes('book') || 
      window.location.pathname.includes('view') || window.location.pathname.includes('manage')) {
    protectPage();
  }
  // Role-specific redirects or content can be added here
});

// Export for forms (global)
window.login = login;
window.signup = signup;
window.logout = logout;
window.checkAuth = checkAuth;
window.protectPage = protectPage;
window.doctors = doctors; // For other pages
window.appointments = appointments;
window.saveData = saveData;
