# TODO: Make Pages Standalone

## Information Gathered
- The `doctor-appointment-system` folder contains HTML prototype files.
- `index.html`: Includes header, hero banner, and footer (keep as is, as it's the home page).
- `login.html`, `signup.html`, `dashboard.html`, `book-appointment.html`, `view-appointments.html`, `manage-appointments.html`, `manage-availability.html`, `select-time.html`, `confirm-appointment.html`: All include header and footer, but no hero banner. These need to be made standalone by removing header and footer.
- Logout button is currently in the header via `updateHeader(user)` in `js/app.js`. Removing header removes logout, so add a standalone logout button in the main content for logged-in pages (dashboard, book-appointment, etc.).
- Ensure logout button does not overlap with hero (but hero is not present on these pages, so no issue).
- No changes needed to `js/app.js` or CSS, as functionality remains via scripts.

## Plan
1. **Remove header and footer from standalone pages**:
   - Edit `login.html`, `signup.html`, `dashboard.html`, `book-appointment.html`, `view-appointments.html`, `manage-appointments.html`, `manage-availability.html`, `select-time.html`, `confirm-appointment.html` to remove `<header>` and `<footer>` sections.
   
2. **Add logout button to logged-in pages**:
   - In `dashboard.html`, `book-appointment.html`, `view-appointments.html`, `manage-appointments.html`, `manage-availability.html`, `select-time.html`, `confirm-appointment.html`, add a logout button in the main content (e.g., after the title or in a fixed position).
   - Use `<button onclick="logout()" class="btn btn-logout">Logout</button>` or similar, styled to not overlap.

3. **Verify standalone behavior**:
   - Ensure pages load without header/footer, and logout works.

## Dependent Files
- All HTML files in `doctor-appointment-system/` except `index.html`.

## Followup Steps
- Test pages in browser to confirm standalone display.
- Ensure logout functionality persists via `js/app.js`.

## Completed Tasks
- [x] Removed header and footer from `dashboard.html`
- [x] Added logout button to `dashboard.html`
- [x] Removed header and footer from `book-appointment.html`
- [x] Added logout button to `book-appointment.html`
- [x] Removed header and footer from `view-appointments.html`
- [x] Added logout button to `view-appointments.html`
- [x] Removed header and footer from `manage-appointments.html`
- [x] Added logout button to `manage-appointments.html`
- [x] Removed header and footer from `manage-availability.html`
- [x] Added logout button to `manage-availability.html`
- [x] Removed header and footer from `select-time.html`
- [x] Added logout button to `select-time.html`
- [x] Removed header and footer from `confirm-appointment.html`
- [x] Added logout button to `confirm-appointment.html`
- [x] Edited `signup.html` to limit role selection to "patient" only
