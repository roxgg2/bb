document.addEventListener('DOMContentLoaded', function () {
  const toggle = document.querySelector('.nav-toggle');
  const menu = document.querySelector('.nav-menu');
  if (toggle && menu) {
    toggle.addEventListener('click', () => {
      menu.classList.toggle('active');
    });
  }

  // Search functionality for doctors by specialty - redirect to doctor list page
  window.searchDoctors = function() {
    const searchInput = document.getElementById('specialty-search');
    const searchTerm = searchInput.value.toLowerCase().trim();

    if (searchTerm) {
      // Redirect to doctor list page with specialty parameter
      window.location.href = '/doctor-list?specialty=' + encodeURIComponent(searchTerm);
    } else {
      // If no search term, redirect to general doctors list
      window.location.href = '/doctor-list';
    }
  };

  // Allow search on Enter key press
  const searchInput = document.getElementById('specialty-search');
  if (searchInput) {
    searchInput.addEventListener('keypress', function(e) {
      if (e.key === 'Enter') {
        searchDoctors();
      }
    });
  }

  // Time slot selection functionality
  window.selectTime = function(time) {
    // Remove selected class from all time slots
    const timeSlots = document.querySelectorAll('.time-slot');
    timeSlots.forEach(slot => slot.classList.remove('selected'));

    // Add selected class to clicked time slot
    const selectedSlot = event.target;
    selectedSlot.classList.add('selected');

    // Enable confirm button
    const confirmBtn = document.getElementById('confirm-time-btn');
    if (confirmBtn) {
      confirmBtn.disabled = false;
    }
  };

  // Confirm time selection
  window.confirmTimeSelection = function() {
    const selectedSlot = document.querySelector('.time-slot.selected');
    if (selectedSlot) {
      const selectedTime = selectedSlot.textContent;
      const selectedDate = document.getElementById('appointment-date').value;

      if (selectedDate) {
        // Redirect to appointment summary with selected time and date
        window.location.href = '/appointment-summary?date=' + selectedDate + '&time=' + encodeURIComponent(selectedTime);
      } else {
        alert('Please select a date first.');
      }
    }
  };

  // Go back function
  window.goBack = function() {
    window.history.back();
  };

  // Confirm appointment
  window.confirmAppointment = function() {
    alert('Appointment confirmed! You will receive a confirmation email shortly.');
    window.location.href = '/view-appointments';
  };

  // Edit appointment
  window.editAppointment = function() {
    window.location.href = '/select-time';
  };
});
