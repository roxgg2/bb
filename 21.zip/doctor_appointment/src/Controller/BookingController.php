<?php

namespace Drupal\doctor_appointment\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Link;
use Drupal\doctor_appointment\Entity\Doctor;
use Drupal\doctor_appointment\Entity\Appointment;

/**
 * Controller for booking related pages.
 */
class BookingController extends ControllerBase {

  /**
   * Displays the list of doctors for booking.
   */
  public function book() {
    $doctors = $this->entityTypeManager()->getStorage('doctor')->loadMultiple();

    $build = [
      '#type' => 'container',
      '#attributes' => ['class' => ['doctor-list']],
      'title' => [
        '#type' => 'html_tag',
        '#tag' => 'h1',
        '#value' => $this->t('Find a Doctor'),
      ],
      'list' => [
        '#theme' => 'item_list',
        '#items' => [],
      ],
    ];

    foreach ($doctors as $doctor) {
      $build['list']['#items'][] = [
        '#markup' => '<div class="doctor-card">' .
          '<h3>' . $doctor->get('name')->value . '</h3>' .
          '<p>Specialty: ' . $doctor->get('specialty')->value . '</p>' .
          '<p>Location: ' . $doctor->get('location')->value . '</p>' .
          Link::createFromRoute($this->t('Select Doctor'), 'doctor_appointment.select_time', ['doctor' => $doctor->id()], ['attributes' => ['class' => ['card-btn']]])->toString() .
          '</div>',
      ];
    }

    return $build;
  }

  /**
   * Displays the select time page for a doctor.
   */
  public function selectTime(Doctor $doctor) {
    return [
      '#theme' => 'page__select_time',
      '#doctor' => $doctor,
      'form' => $this->formBuilder()->getForm('\Drupal\doctor_appointment\Form\SelectTimeForm', $doctor),
    ];
  }

  /**
   * Displays the user's appointments.
   */
  public function viewAppointments() {
    $user = $this->currentUser();
    $appointments = $this->entityTypeManager()->getStorage('appointment')->loadByProperties([
      'patient' => $user->id(),
    ]);

    $build = [
      '#type' => 'container',
      'title' => [
        '#type' => 'html_tag',
        '#tag' => 'h1',
        '#value' => $this->t('Your Appointments'),
      ],
      'list' => [
        '#theme' => 'item_list',
        '#items' => [],
      ],
    ];

    foreach ($appointments as $appointment) {
      $doctor = $appointment->get('doctor')->entity;
      $build['list']['#items'][] = [
        '#markup' => '<div class="appointment-card">' .
          '<h3>' . $appointment->get('title')->value . '</h3>' .
          '<p>Doctor: ' . ($doctor ? $doctor->get('name')->value : '') . '</p>' .
          '<p>Date: ' . $appointment->get('appointment_date')->value . '</p>' .
          '<p>Time: ' . $appointment->get('time')->value . '</p>' .
          '<p>Status: ' . $appointment->get('status')->value . '</p>' .
          '</div>',
      ];
    }

    return $build;
  }

  /**
   * Displays appointments for the doctor to manage.
   */
  public function manageAppointments() {
    $user = $this->currentUser();
    $doctors = $this->entityTypeManager()->getStorage('doctor')->loadByProperties([
      'uid' => $user->id(),
    ]);

    $appointments = [];
    if ($doctors) {
      $doctor = reset($doctors);
      $appointments = $this->entityTypeManager()->getStorage('appointment')->loadByProperties([
        'doctor' => $doctor->id(),
      ]);
    }

    $build = [
      '#type' => 'container',
      'title' => [
        '#type' => 'html_tag',
        '#tag' => 'h1',
        '#value' => $this->t('Manage Appointments'),
      ],
      'list' => [
        '#theme' => 'item_list',
        '#items' => [],
      ],
    ];

    foreach ($appointments as $appointment) {
      $patient = $appointment->get('patient')->entity;
      $status = $appointment->get('status')->value;
      $actions = '';
      if ($status == 'pending') {
        $actions = Link::createFromRoute($this->t('Accept'), 'doctor_appointment.update_status', ['appointment' => $appointment->id(), 'status' => 'accepted'])->toString() . ' | ' .
          Link::createFromRoute($this->t('Reject'), 'doctor_appointment.update_status', ['appointment' => $appointment->id(), 'status' => 'rejected'])->toString();
      }
      $build['list']['#items'][] = [
        '#markup' => '<div class="appointment-card">' .
          '<h3>' . $appointment->get('title')->value . '</h3>' .
          '<p>Patient: ' . ($patient ? $patient->getDisplayName() : '') . '</p>' .
          '<p>Date: ' . $appointment->get('appointment_date')->value . '</p>' .
          '<p>Time: ' . $appointment->get('time')->value . '</p>' .
          '<p>Status: ' . $status . '</p>' .
          $actions .
          '</div>',
      ];
    }

    return $build;
  }

  /**
   * Updates the status of an appointment.
   */
  public function updateStatus(Appointment $appointment, $status) {
    $appointment->set('status', $status);
    $appointment->save();
    $this->messenger()->addMessage($this->t('Appointment status updated.'));
    return $this->redirect('doctor_appointment.dashboard');
  }

}
