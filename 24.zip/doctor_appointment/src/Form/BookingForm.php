<?php

namespace Drupal\doctor_appointment\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\doctor_appointment\Entity\Appointment;
use Drupal\doctor_appointment\Entity\Doctor;

/**
 * Form for confirming appointment booking.
 */
class BookingForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'booking_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $tempstore = \Drupal::service('tempstore.private')->get('doctor_appointment');
    $doctor_id = $tempstore->get('doctor_id');
    $date = $tempstore->get('date');
    $times = $tempstore->get('times');

    if (!$doctor_id || !$date || !$times) {
      $form['error'] = [
        '#markup' => $this->t('No appointment data found. Please start over.'),
      ];
      return $form;
    }

    $doctor = \Drupal::entityTypeManager()->getStorage('doctor')->load($doctor_id);

    $form['summary'] = [
      '#type' => 'fieldset',
      '#title' => $this->t('Appointment Summary'),
      'doctor' => [
        '#markup' => '<p><strong>Doctor:</strong> ' . $doctor->get('name')->value . '</p>',
      ],
      'date' => [
        '#markup' => '<p><strong>Date:</strong> ' . $date . '</p>',
      ],
      'time' => [
        '#markup' => '<p><strong>Time:</strong> ' . implode(', ', $times) . '</p>',
      ],
    ];

    $form['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Confirm Appointment'),
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $tempstore = \Drupal::service('tempstore.private')->get('doctor_appointment');
    $doctor_id = $tempstore->get('doctor_id');
    $date = $tempstore->get('date');
    $times = $tempstore->get('times');
    $user = \Drupal::currentUser();

    // Create appointment entity.
    $appointment = Appointment::create([
      'title' => 'Appointment with ' . \Drupal::entityTypeManager()->getStorage('doctor')->load($doctor_id)->get('name')->value . ' on ' . $date,
      'patient' => $user->id(),
      'doctor' => $doctor_id,
      'appointment_date' => $date,
      'time' => implode(', ', $times),
      'status' => 'pending',
    ]);
    $appointment->save();

    // Clear tempstore.
    $tempstore->delete('doctor_id');
    $tempstore->delete('date');
    $tempstore->delete('times');

    \Drupal::messenger()->addMessage($this->t('Appointment booked successfully!'));
    $form_state->setRedirect('doctor_appointment.dashboard');
  }

}
