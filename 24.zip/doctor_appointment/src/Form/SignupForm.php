<?php

namespace Drupal\doctor_appointment\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\user\Entity\User;

/**
 * Custom signup form for the doctor appointment system.
 */
class SignupForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'doctor_appointment_signup';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $form['name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Name'),
      '#required' => TRUE,
    ];

    $form['email'] = [
      '#type' => 'email',
      '#title' => $this->t('Email'),
      '#required' => TRUE,
    ];

    $form['password'] = [
      '#type' => 'password',
      '#title' => $this->t('Password'),
      '#required' => TRUE,
    ];

    $form['role'] = [
      '#type' => 'radios',
      '#title' => $this->t('Role'),
      '#options' => [
        'patient' => $this->t('Patient'),
        'doctor' => $this->t('Doctor'),
      ],
      '#default_value' => 'patient',
      '#required' => TRUE,
    ];

    $form['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Signup'),
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $name = $form_state->getValue('name');
    $email = $form_state->getValue('email');
    $password = $form_state->getValue('password');
    $role = $form_state->getValue('role');

    $user = User::create();
    $user->setUsername($name);
    $user->setEmail($email);
    $user->setPassword($password);
    $user->set('status', 1);
    if ($role === 'doctor') {
      $user->addRole('doctor');
    }
    $user->save();

    \Drupal::messenger()->addMessage($this->t('Signup successful. Please login.'));
    $form_state->setRedirect('doctor_appointment.login');
  }

}
