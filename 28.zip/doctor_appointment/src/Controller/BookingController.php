<?php

namespace Drupal\doctor_appointment\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Link;
use Drupal\doctor_appointment\Entity\Doctor;
use Drupal\doctor_appointment\Entity\Appointment;

/**
 * Controller for booking related pages.
 */
class BookingController extends ControllerBase {

  /**
   * Displays the list of doctors for booking.
   */
  public function book() {
    $search_query = \Drupal::request()->query->get('specialty', '');

    $query = $this->entityTypeManager()->getStorage('doctor')->getQuery();

    if (!empty($search_query)) {
      $query->condition('specialty', $search_query, 'CONTAINS');
    }

    $doctor_ids = $query->execute();
    $doctors = $this->entityTypeManager()->getStorage('doctor')->loadMultiple($doctor_ids);

    $build = [
      '#type' => 'container',
      '#attributes' => ['class' => ['doctor-list']],
      'search_form' => [
        '#type' => 'container',
        '#attributes' => ['class' => ['search-container']],
        'title' => [
          '#type' => 'html_tag',
          '#tag' => 'h1',
          '#value' => $this->t('Find a Doctor'),
        ],
        'form' => [
          '#type' => 'form',
          '#method' => 'GET',
          '#attributes' => ['class' => ['search-form']],
          'search' => [
            '#type' => 'textfield',
            '#title' => $this->t('Search by Specialty'),
            '#default_value' => $search_query,
            '#attributes' => ['placeholder' => $this->t('Enter specialty (e.g., Cardiology, Dermatology)')],
          ],
          'submit' => [
            '#type' => 'submit',
            '#value' => $this->t('Search'),
            '#attributes' => ['class' => ['search-btn']],
          ],
        ],
      ],
      'results' => [
        '#type' => 'container',
        '#attributes' => ['class' => ['doctor-results']],
      ],
    ];

    if (!empty($search_query)) {
      $build['results']['search_info'] = [
        '#markup' => '<p class="search-results-info">Showing results for: <strong>' . $search_query . '</strong></p>',
      ];
    }

    if (empty($doctors)) {
      $build['results']['no_results'] = [
        '#markup' => '<p class="no-results">No doctors found matching your search criteria.</p>',
      ];
    } else {
      $build['results']['list'] = [
        '#theme' => 'item_list',
        '#items' => [],
        '#attributes' => ['class' => ['doctor-grid']],
      ];

      foreach ($doctors as $doctor) {
        $build['results']['list']['#items'][] = [
          '#markup' => '<div class="doctor-card">' .
            '<h3>' . $doctor->get('name')->value . '</h3>' .
            '<p class="specialty">Specialty: ' . $doctor->get('specialty')->value . '</p>' .
            '<p class="location">Location: ' . $doctor->get('location')->value . '</p>' .
            Link::createFromRoute($this->t('Select Doctor'), 'doctor_appointment.select_time', ['doctor' => $doctor->id()], ['attributes' => ['class' => ['card-btn']]])->toString() .
            '</div>',
        ];
      }
    }

    return $build;
  }

  /**
   * Displays the select time page for a doctor.
   */
  public function selectTime(Doctor $doctor) {
    $build = [
      '#type' => 'container',
      'doctor_details' => [
        '#markup' => '<h2>' . $doctor->get('name')->value . '</h2><p>Specialty: ' . $doctor->get('specialty')->value . '</p><p>Location: ' . $doctor->get('location')->value . '</p>',
      ],
      'form' => $this->formBuilder()->getForm('\Drupal\doctor_appointment\Form\SelectTimeForm', $doctor),
    ];

    return $build;
  }

  /**
   * Displays the user's appointments.
   */
  public function viewAppointments() {
    $user = $this->currentUser();
    $appointments = $this->entityTypeManager()->getStorage('appointment')->loadByProperties([
      'patient' => $user->id(),
    ]);

    $build = [
      '#type' => 'container',
      'title' => [
        '#type' => 'html_tag',
        '#tag' => 'h1',
        '#value' => $this->t('Your Appointments'),
      ],
      'list' => [
        '#theme' => 'item_list',
        '#items' => [],
      ],
    ];

    foreach ($appointments as $appointment) {
      $doctor = $appointment->get('doctor')->entity;
      $build['list']['#items'][] = [
        '#markup' => '<div class="appointment-card">' .
          '<h3>' . $appointment->get('title')->value . '</h3>' .
          '<p>Doctor: ' . ($doctor ? $doctor->get('name')->value : '') . '</p>' .
          '<p>Date: ' . $appointment->get('appointment_date')->value . '</p>' .
          '<p>Time: ' . $appointment->get('time')->value . '</p>' .
          '<p>Status: ' . $appointment->get('status')->value . '</p>' .
          '</div>',
      ];
    }

    return $build;
  }

  /**
   * Displays appointments for the doctor to manage.
   */
  public function manageAppointments() {
    $user = $this->currentUser();
    $doctors = $this->entityTypeManager()->getStorage('doctor')->loadByProperties([
      'uid' => $user->id(),
    ]);

    $appointments = [];
    if ($doctors) {
      $doctor = reset($doctors);
      $appointments = $this->entityTypeManager()->getStorage('appointment')->loadByProperties([
        'doctor' => $doctor->id(),
      ]);
    }

    $build = [
      '#type' => 'container',
      'title' => [
        '#type' => 'html_tag',
        '#tag' => 'h1',
        '#value' => $this->t('Manage Appointments'),
      ],
      'list' => [
        '#theme' => 'item_list',
        '#items' => [],
      ],
    ];

    foreach ($appointments as $appointment) {
      $patient = $appointment->get('patient')->entity;
      $status = $appointment->get('status')->value;
      $actions = '';
      if ($status == 'pending') {
        $actions = Link::createFromRoute($this->t('Accept'), 'doctor_appointment.update_status', ['appointment' => $appointment->id(), 'status' => 'accepted'])->toString() . ' | ' .
          Link::createFromRoute($this->t('Reject'), 'doctor_appointment.update_status', ['appointment' => $appointment->id(), 'status' => 'rejected'])->toString();
      }
      $build['list']['#items'][] = [
        '#markup' => '<div class="appointment-card">' .
          '<h3>' . $appointment->get('title')->value . '</h3>' .
          '<p>Patient: ' . ($patient ? $patient->getDisplayName() : '') . '</p>' .
          '<p>Date: ' . $appointment->get('appointment_date')->value . '</p>' .
          '<p>Time: ' . $appointment->get('time')->value . '</p>' .
          '<p>Status: ' . $status . '</p>' .
          $actions .
          '</div>',
      ];
    }

    return $build;
  }

  /**
   * Updates the status of an appointment.
   */
  public function updateStatus(Appointment $appointment, $status) {
    $appointment->set('status', $status);
    $appointment->save();
    $this->messenger()->addMessage($this->t('Appointment status updated.'));
    return $this->redirect('doctor_appointment.dashboard');
  }

}
