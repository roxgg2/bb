<?php

namespace Drupal\doctor_appointment\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\doctor_appointment\Entity\Doctor;

/**
 * Form for selecting date and time for appointment.
 */
class SelectTimeForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'select_time_form';
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state, Doctor $doctor = NULL) {
    $form_state->set('doctor', $doctor);

    $form['selected_time'] = [
      '#type' => 'hidden',
      '#default_value' => '',
    ];

    $form['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Next: Confirm Appointment'),
      '#attributes' => ['style' => 'display:none;'],
    ];

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $doctor = $form_state->get('doctor');
    $selected_time = $form_state->getValue('selected_time');

    // Get date from request (set by JS)
    $request = \Drupal::request();
    $date = $request->request->get('appointment-date');

    $tempstore = \Drupal::service('tempstore.private')->get('doctor_appointment');
    $tempstore->set('doctor_id', $doctor->id());
    $tempstore->set('date', $date);
    $tempstore->set('times', [$selected_time]);

    $form_state->setRedirect('doctor_appointment.confirm');
  }

}
