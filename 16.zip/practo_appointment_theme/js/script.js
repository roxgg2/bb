document.addEventListener('DOMContentLoaded', function () {
  // Load appointment details from localStorage on appointment summary page
  if (window.location.pathname.includes('appointment-summary')) {
    const storedDate = localStorage.getItem('selectedAppointmentDate');
    const storedTime = localStorage.getItem('selectedAppointmentTime');
    const storedDoctorId = localStorage.getItem('selectedDoctorId');

    if (storedDate && document.getElementById('summary-date')) {
      document.getElementById('summary-date').textContent = storedDate;
    }
    if (storedTime && document.getElementById('summary-time')) {
      document.getElementById('summary-time').textContent = storedTime;
    }

    // If we have a doctor ID, we could potentially load doctor details here
    // For now, the template will use the node data passed from Drupal
  }
  const toggle = document.querySelector('.nav-toggle');
  const menu = document.querySelector('.nav-menu');
  if (toggle && menu) {
    toggle.addEventListener('click', () => {
      menu.classList.toggle('active');
    });
  }

  // Search functionality for doctors by specialty - redirect to doctor list page
  window.searchDoctors = function() {
    const searchInput = document.getElementById('specialty-search');
    const searchTerm = searchInput.value.toLowerCase().trim();

    if (searchTerm) {
      // Redirect to doctor list page with specialty parameter
      window.location.href = '/doctor-list?specialty=' + encodeURIComponent(searchTerm);
    } else {
      // If no search term, redirect to general doctors list
      window.location.href = '/doctor-list';
    }
  };

  // Allow search on Enter key press
  const searchInput = document.getElementById('specialty-search');
  if (searchInput) {
    searchInput.addEventListener('keypress', function(e) {
      if (e.key === 'Enter') {
        searchDoctors();
      }
    });
  }

  // Time slot selection functionality
  window.selectTime = function(time) {
    // Remove selected class from all time slots
    const timeSlots = document.querySelectorAll('.time-slot');
    timeSlots.forEach(slot => slot.classList.remove('selected'));

    // Add selected class to clicked time slot
    event.target.classList.add('selected');

    // Enable confirm button
    const confirmBtn = document.getElementById('confirm-time-btn');
    if (confirmBtn) {
      confirmBtn.disabled = false;
    }
  };

  // Confirm time selection
  window.confirmTimeSelection = function() {
    const selectedSlot = document.querySelector('.time-slot.selected');
    if (selectedSlot) {
      const selectedTime = selectedSlot.textContent.trim();
      const selectedDate = document.getElementById('appointment-date').value;

      if (selectedDate) {
        // Store selected time and date in localStorage for appointment summary
        localStorage.setItem('selectedAppointmentDate', selectedDate);
        localStorage.setItem('selectedAppointmentTime', selectedTime);

        // Get doctor ID from URL
        const urlParts = window.location.pathname.split('/');
        const doctorId = urlParts[urlParts.length - 1];

        // Store doctor ID as well
        localStorage.setItem('selectedDoctorId', doctorId);

        // Redirect to appointment summary with selected time and date
        window.location.href = '/appointment-summary?date=' + encodeURIComponent(selectedDate) + '&time=' + encodeURIComponent(selectedTime) + '&doctor=' + doctorId;
      } else {
        alert('Please select a date first.');
      }
    } else {
      alert('Please select a time slot first.');
    }
  };

  // Go back function
  window.goBack = function() {
    window.history.back();
  };

  // Confirm appointment
  window.confirmAppointment = function() {
    // Create a custom confirmation dialog
    const confirmDialog = document.createElement('div');
    confirmDialog.innerHTML = `
      <div style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 10000; display: flex; align-items: center; justify-content: center;">
        <div style="background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.3); max-width: 400px; width: 90%; text-align: center;">
          <h3 style="color: #007bff; margin-bottom: 20px;">Confirm Appointment</h3>
          <p style="margin-bottom: 30px; color: #666;">Are you sure you want to book this appointment?</p>
          <div style="display: flex; gap: 15px; justify-content: center;">
            <button id="confirm-yes" style="background: #007bff; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer;">Yes, Book Appointment</button>
            <button id="confirm-no" style="background: #6c757d; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer;">Cancel</button>
          </div>
        </div>
      </div>
    `;
    document.body.appendChild(confirmDialog);

    document.getElementById('confirm-yes').onclick = function() {
      document.body.removeChild(confirmDialog);
      alert('Appointment request sent! The doctor will review and respond to your request.');
      // Clear stored appointment data
      localStorage.removeItem('selectedAppointmentDate');
      localStorage.removeItem('selectedAppointmentTime');
      localStorage.removeItem('selectedDoctorId');
      window.location.href = '/view-appointment';
    };

    document.getElementById('confirm-no').onclick = function() {
      document.body.removeChild(confirmDialog);
    };
  };

  // Edit appointment
  window.editAppointment = function() {
    const storedDoctorId = localStorage.getItem('selectedDoctorId');
    if (storedDoctorId) {
      window.location.href = '/select-time/' + storedDoctorId;
    } else {
      window.location.href = '/select-time';
    }
  };

  // Confirm logout
  window.confirmLogout = function() {
    // Create a custom logout confirmation dialog
    const logoutDialog = document.createElement('div');
    logoutDialog.innerHTML = `
      <div style="position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 10000; display: flex; align-items: center; justify-content: center;">
        <div style="background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.3); max-width: 400px; width: 90%; text-align: center;">
          <h3 style="color: #dc3545; margin-bottom: 20px;">Confirm Logout</h3>
          <p style="margin-bottom: 30px; color: #666;">Are you sure you want to logout?</p>
          <div style="display: flex; gap: 15px; justify-content: center;">
            <button id="logout-yes" style="background: #dc3545; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer;">Yes, Logout</button>
            <button id="logout-no" style="background: #6c757d; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer;">Cancel</button>
          </div>
        </div>
      </div>
    `;
    document.body.appendChild(logoutDialog);

    document.getElementById('logout-yes').onclick = function() {
      document.body.removeChild(logoutDialog);
      window.location.href = '/user/logout?destination=/';
    };

    document.getElementById('logout-no').onclick = function() {
      document.body.removeChild(logoutDialog);
    };
  };
});
